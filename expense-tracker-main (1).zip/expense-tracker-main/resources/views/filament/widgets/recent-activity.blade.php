<x-filament::widget>
    <x-filament::card>
        <div class="text-sm font-medium text-gray-500">
            Recent Activity
        </div>
        {{ $this->table }}
    </x-filament::card>
</x-filament::widget>
