<td
    <?php echo e($attributes->class(['filament-tables-checkbox-cell w-4 whitespace-nowrap px-4'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\Users\HP\Documents\Kuliah\Semester 4\Prak RPL\Prak-RPL-KEL-07\expense-tracker-main\vendor\filament\tables\src\/../resources/views/components/checkbox/cell.blade.php ENDPATH**/ ?>