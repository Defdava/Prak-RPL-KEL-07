<?php if (isset($component)) { $__componentOriginal0a6087579beaae9feec0056cadcfb42f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a6087579beaae9feec0056cadcfb42f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal9b945b32438afb742355861768089b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b945b32438afb742355861768089b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-sm font-medium text-gray-500">
            Recent Activity
        </div>
        <?php echo e($this->table); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b945b32438afb742355861768089b04)): ?>
<?php $attributes = $__attributesOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__attributesOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b945b32438afb742355861768089b04)): ?>
<?php $component = $__componentOriginal9b945b32438afb742355861768089b04; ?>
<?php unset($__componentOriginal9b945b32438afb742355861768089b04); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a6087579beaae9feec0056cadcfb42f)): ?>
<?php $attributes = $__attributesOriginal0a6087579beaae9feec0056cadcfb42f; ?>
<?php unset($__attributesOriginal0a6087579beaae9feec0056cadcfb42f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a6087579beaae9feec0056cadcfb42f)): ?>
<?php $component = $__componentOriginal0a6087579beaae9feec0056cadcfb42f; ?>
<?php unset($__componentOriginal0a6087579beaae9feec0056cadcfb42f); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Documents\Kuliah\Semester 4\Prak RPL\Prak-RPL-KEL-07\expense-tracker-main\resources\views/filament/widgets/recent-activity.blade.php ENDPATH**/ ?>