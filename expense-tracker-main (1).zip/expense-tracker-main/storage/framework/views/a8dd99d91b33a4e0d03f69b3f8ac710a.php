<div
    <?php echo e($attributes->class([
            'filament-tables-container rounded-xl border border-gray-300 bg-white shadow-sm',
            'dark:border-gray-700 dark:bg-gray-800' => config('tables.dark_mode'),
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\HP\Documents\Kuliah\Semester 4\Prak RPL\Prak-RPL-KEL-07\expense-tracker-main\vendor\filament\tables\src\/../resources/views/components/container.blade.php ENDPATH**/ ?>