<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\Users\HP\Documents\Kuliah\Semester 4\Prak RPL\Prak-RPL-KEL-07\expense-tracker-main\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>