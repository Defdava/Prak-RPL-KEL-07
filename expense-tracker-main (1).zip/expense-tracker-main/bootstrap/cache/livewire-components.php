<?php return array (
  'register' => 'App\\Http\\Livewire\\Register',
);